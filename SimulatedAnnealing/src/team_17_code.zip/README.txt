The main file is in the SimulatedAnnealing.java, the cooling rate variable should be changed in order to change
cooling rate. In order to change the sets, uncomment the cities in the main function.